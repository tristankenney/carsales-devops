import sys
sys.path.insert(0,"/tmp/ansible_ec2_vpc_igw_payload_AK7Ng2/ansible_ec2_vpc_igw_payload.zip")
