from pkgutil import extend_path
__path__=extend_path(__path__,__name__)
__version__="2.8.3"
__author__="Ansible, Inc."
